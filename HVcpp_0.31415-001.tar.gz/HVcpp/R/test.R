
#' plot.test1
#'
#' @export plot.test1
plot.test1 = function() {}

#' plot.test2
#'
#' @export
plot.test2 = function() {}
