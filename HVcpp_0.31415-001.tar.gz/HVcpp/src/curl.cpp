#include <Rcpp.h>
#include <string>
#include <curl/curl.h>

using namespace Rcpp;


	   
