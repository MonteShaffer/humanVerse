
## utils::globalVariables(c(".github.humanVerse.raw", ".github.humanVerse.view"));

## utils::globalVariables(c(".random.seed.memory"));

utils::globalVariables(c(".humanVerse"));
utils::globalVariables(c("imdb.data"));


